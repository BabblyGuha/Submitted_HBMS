package com.capgemini.hbms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hbms.dao.AuthenticationDaoImplementation;
import com.capgemini.hbms.dao.IAuthenticationDao;
import com.capgemini.hbms.exception.AdminException;
import com.capgemini.hbms.exception.ConnectionException;

public class AuthenticationDaoImplementationTest {

	IAuthenticationDao dao = null;
	@Test
	public void testCheckLoginCredentials() {

		dao = new AuthenticationDaoImplementation();
		try {
			assertEquals("Admin",dao.checkLoginCredentials("A01", "Aa@123"));
		} 
		
		catch (Exception e) {
			System.err.println("Error in Junit Testing !!!");
		} 
	}

}
