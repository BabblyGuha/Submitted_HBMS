package com.capgemini.hbms.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.dao.IUserDao;
import com.capgemini.hbms.dao.UserDaoImplementation;
import com.capgemini.hbms.exception.BookingException;
import com.capgemini.hbms.exception.ConnectionException;

public class UserDaoImplementationTest {

	IUserDao dao = null;
	@Test
	public void testAddBookingDetails() {
		dao = new UserDaoImplementation();
		BookingDetailsBean booking = new BookingDetailsBean("R07", "C44", LocalDate.of(2018, 9, 12), LocalDate.of(2018, 9, 13), 2, 2); 
		try {
			assertEquals("B84",dao.addBookingDetails(booking));
		} 
		catch (Exception e) {
			System.err.println("Error in Junit Testing !!!");
		} 
	}

}
