package com.capgemini.hbms.exception;

public class ConnectionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConnectionException(String message) {
		super(message);
	}
	
	

}
