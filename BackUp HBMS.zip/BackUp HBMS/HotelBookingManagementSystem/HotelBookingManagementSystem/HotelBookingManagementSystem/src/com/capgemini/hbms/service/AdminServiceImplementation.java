package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.AdminDaoImplementation;
import com.capgemini.hbms.dao.IAdminDao;
import com.capgemini.hbms.exception.AdminException;
import com.capgemini.hbms.exception.BookingException;
import com.capgemini.hbms.exception.ConnectionException;
import com.capgemini.hbms.exception.HotelException;
import com.capgemini.hbms.exception.RoomException;

public class AdminServiceImplementation implements IAdminService{

	IAdminDao adminDao = null;
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	addHotelDetails
			- Input Parameters	:	HotelBean object
			- Return Type		:	String HotelId
			- Throws			:  	ConnectionException, HotelException
			- Author			:	Jhilik Guha
			- Creation Date		:	30/08/2018
			- Description		:	Calling addHotelDetails of dao to add Hotel to Database
	********************************************************************************************************/
	
	@Override
	public String addHotelDetails(HotelBean hotel) throws ConnectionException, HotelException {

		adminDao = new AdminDaoImplementation();
		return adminDao.addHotelDetails(hotel);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	modifyHotelDetails
			- Input Parameters	:	String update query for hotel
			- Return Type		:	String (Success or Error)
			- Throws			:  	ConnectionException, HotelException
			- Author			:	Jhilik Guha
			- Creation Date		:	30/08/2018
			- Description		:	Calling modifyHotelDetails of dao modify Hotel in Database
	********************************************************************************************************/
	
	@Override
	public String modifyHotelDetails(String modifyHotel) throws ConnectionException, HotelException {
		adminDao = new AdminDaoImplementation();
		return adminDao.modifyHotelDetails(modifyHotel);
	}
	
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	deleteHotelDetails
			- Input Parameters	:	String HotelId
			- Return Type		:	String HotelId
			- Throws			:  	ConnectionException, HotelException
			- Author			:	Jhilik Guha
			- Creation Date		:	30/08/2018
			- Description		:	Calling deleteHotelDetails of dao to delete Hotel from Database
	********************************************************************************************************/
	@Override
	public String deleteHotelDetails(String hotelId) throws ConnectionException, HotelException {
		adminDao = new AdminDaoImplementation();
		return adminDao.deleteHotelDetails(hotelId);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	displayAllHotels
			- Input Parameters	:	No Input Parameters
			- Return Type		:	ArrayList<String>
			- Throws			:  	ConnectionException, HotelException
			- Author			:	Jhilik Guha
			- Creation Date		:	30/08/2018
			- Description		:	Calling displayAllHotels of dao to display all Hotel details from Database
	********************************************************************************************************/
	@Override
	public ArrayList<String> displayAllHotels() throws ConnectionException, HotelException {
		adminDao = new AdminDaoImplementation();
		return adminDao.displayAllHotels();
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	addRoomDetails
			- Input Parameters	:	RoomDetailsBean
			- Return Type		:	String roomId
			- Throws			:  	ConnectionException, RoomException
			- Author			:	Jhilik Guha
			- Creation Date		:	01/09/2018
			- Description		:	Calling addRoomDetails of dao to add Room details to Database
	********************************************************************************************************/
	@Override
	public String addRoomDetails(RoomDetailsBean room) throws ConnectionException, RoomException {
		adminDao = new AdminDaoImplementation();
		return adminDao.addRoomDetails(room);
	}
	
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	modifyRoomDetails
			- Input Parameters	:	String update query for hotel
			- Return Type		:	String (Success or Error)
			- Throws			:  	ConnectionException, RoomException
			- Author			:	Jhilik Guha
			- Creation Date		:	01/09/2018
			- Description		:	Calling modifyRoomDetails of dao to modify Room in Database
	********************************************************************************************************/
	@Override
	public String modifyRoomDetails(String modifyRoom) throws ConnectionException, RoomException {
		adminDao = new AdminDaoImplementation();
		return adminDao.modifyRoomDetails(modifyRoom);
	}
	
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	deleteRoomDetails
			- Input Parameters	:	String RoomId
			- Return Type		:	String RoomId
			- Throws			:  	ConnectionException, RoomException
			- Author			:	Jhilik Guha
			- Creation Date		:	01/09/2018
			- Description		:	Calling deleteRoomDetails of dao to delete Room from Database
	********************************************************************************************************/
	@Override
	public String deleteRoomDetails(String roomId) throws ConnectionException, RoomException {
		adminDao = new AdminDaoImplementation();
		return adminDao.deleteRoomDetails(roomId);
	}
	
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	displayAllRooms
			- Input Parameters	:	No Input Parameters
			- Return Type		:	ArrayList<String>
			- Throws			:  	ConnectionException, RoomException
			- Author			:	Jhilik Guha
			- Creation Date		:	02/09/2018
			- Description		:	Calling displayAllRooms of dao to display all Room details from Database
	********************************************************************************************************/
	@Override
	public ArrayList<String> displayAllRooms() throws ConnectionException, RoomException {

		adminDao = new AdminDaoImplementation();
		return adminDao.displayAllRooms();
	}


	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	viewHotels
			- Input Parameters	:	No Input Parameters
			- Return Type		:	List<HotelBean>
			- Throws			:  	ConnectionException, HotelException
			- Author			:	Jhilik Guha
			- Creation Date		:	02/09/2018
			- Description		:	Calling viewHotels of dao to display all the existing Hotels from Database
	********************************************************************************************************/
	@Override
	public List<HotelBean> viewHotels() throws ConnectionException, HotelException {
		adminDao = new AdminDaoImplementation();
		return adminDao.viewHotels();
	}
	
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	viewBookingsOfSpecificHotel
			- Input Parameters	:	String hotelId
			- Return Type		:	List<BookingDetailsBean>
			- Throws			:  	ConnectionException, BookingException
			- Author			:	Jhilik Guha
			- Creation Date		:	02/09/2018
			- Description		:	Calling viewBookingsOfSpecificHotel of dao to display all the bookings of a specific hotel from Database
	********************************************************************************************************/
	@Override
	public List<BookingDetailsBean> viewBookingsOfSpecificHotel(String HotelId) throws ConnectionException, BookingException {

		adminDao = new AdminDaoImplementation();
		return adminDao.viewBookingsOfSpecificHotel(HotelId);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	viewGuestListofSpecificHotel
			- Input Parameters	:	String hotelId
			- Return Type		:	List<String>
			- Throws			:  	ConnectionException, BookingException
			- Author			:	Jhilik Guha
			- Creation Date		:	02/09/2018
			- Description		:	Calling viewGuestListofSpecificHotel of dao to display all the guests' list of a specific hotel from Database
	********************************************************************************************************/
	@Override
	public List<String> viewGuestListofSpecificHotel(String HotelId) throws ConnectionException, BookingException {
	
		adminDao = new AdminDaoImplementation();
		return adminDao.viewGuestListofSpecificHotel(HotelId);
		
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	viewBookingsforSpecifiedDate
			- Input Parameters	:	String hotelId
			- Return Type		:	List<String>
			- Throws			:  	ConnectionException, BookingException
			- Author			:	Jhilik Guha
			- Creation Date		:	02/09/2018
			- Description		:	Calling viewBookingsforSpecifiedDate of dao to display all the bookings on a specific date from Database
	*******************************************************************************************************/
	@Override
	public List<BookingDetailsBean> viewBookingsforSpecifiedDate(LocalDate bookOfDate) throws ConnectionException, BookingException {
		
		adminDao = new AdminDaoImplementation();
		return adminDao.viewBookingsforSpecifiedDate(bookOfDate);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	searchRoom
			- Input Parameters	:	String hotelId
			- Return Type		:	List<RoomDetailsBean>
			- Throws			:  	ConnectionException, BookingException, RoomException
			- Author			:	Jhilik Guha
			- Creation Date		:	04/09/2018
			- Description		:	Calling searchRoom of dao to search for all the rooms for the requested hotelId
	********************************************************************************************************/
	
	@Override
	public List<RoomDetailsBean> searchRoom(String hotelId) throws ConnectionException, BookingException, RoomException {
		
		adminDao = new AdminDaoImplementation();
		return adminDao.searchRoom(hotelId);
	}
	
	/*****************************************************************************************************
	 *						<<<<<<<<<<<<<  Validation Methods  >>>>>>>>>>>>>
	 *****************************************************************************************************/
	
	//Validate Fax
	@Override
	public boolean validateFax(String fax) {

		Pattern p = Pattern.compile("[1-9]{1}[0-9]{11}");
		Matcher m = p.matcher(fax);
		return m.matches();
	}

	//Validate Rating
	@Override
	public boolean validateRating(String rating) {

		Pattern p = Pattern.compile("[0-9]{1}[*]{1}");
		Matcher m = p.matcher(rating);
		return m.matches();
	}

	//Validate AverageRatePerNight
	@Override
	public boolean validateAverageRatePerNight(String averageRatePerNight) {

		Pattern p = Pattern.compile("[0-9]+");
		Matcher m = p.matcher(averageRatePerNight);
		return m.matches();
	}
	
	//Validate Hotel ID
	@Override
	public boolean validateHotelId(String hotelId) {

		Pattern p = Pattern.compile("[H][0-9]{1,}");
		Matcher m = p.matcher(hotelId);
		return m.matches();
	}
	
	//Validate Description
	@Override
	public boolean validateDescription(String description) {

		Pattern p = Pattern.compile("^\\d*[a-zA-Z ]{1,50}\\d*");
		Matcher m = p.matcher(description);
		return m.matches();
		
	}
	
	//Validate Address
	@Override
	public boolean validateAddress(String address) {

		Pattern p = Pattern.compile("^\\d*[a-zA-Z -,]{1,25}\\d*");
		Matcher m = p.matcher(address);
		return m.matches();
		
	}
	
	//Validate Room ID
	@Override
	public boolean validateRoomId(String roomId) {

		Pattern p = Pattern.compile("[R][0-9]{1,}");
		Matcher m = p.matcher(roomId);
		return m.matches();
		
	}
	
	//Validate Room Number
	@Override
	public boolean validateRoomNo(String roomNo) {

		Pattern p = Pattern.compile("[0-9]{3}");
		Matcher m = p.matcher(roomNo);
		return m.matches();
	}
	
	//Validate Room Type
	@Override
	public boolean validateRoomType(String roomType) {

		Pattern p = Pattern.compile("^\\d*[a-zA-Z -]{1,20}\\d*");
		Matcher m = p.matcher(roomType);
		return m.matches();
	}
	
	//Validate Availability
	@Override
	public boolean validateAvailability(String availability) {

		Pattern p = Pattern.compile("[0-1]{1}");
		Matcher m = p.matcher(availability);
		return m.matches();
	}
	
	//Validate User ID
	@Override
	public boolean validateUserId(String userId) {

		Pattern p = Pattern.compile("[C][0-9]{2}");
		Matcher m = p.matcher(userId);
		return m.matches();
	}
	
	//Validate Date
	@Override
	public boolean validateDate(String date) {

		Pattern p = Pattern.compile("[0-9]{2}/[0-9]{2}/[0-9]{4}");
		Matcher m = p.matcher(date);
		return m.matches();
	}

	@Override
	public boolean validateCity(String city) {

		Pattern p = Pattern.compile("^[A-Za-z\\s]{1,10}$");
		Matcher m = p.matcher(city);
		return m.matches();
	}
}
