package com.capgemini.hbms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hbms.dao.AdminDaoImplementation;
import com.capgemini.hbms.dao.IAdminDao;
import com.capgemini.hbms.exception.ConnectionException;
import com.capgemini.hbms.exception.HotelException;

public class AdminDaoImplementationTest {

	IAdminDao dao = null;
	@Test
	public void testModifyHotelDetails() {
		dao = new AdminDaoImplementation();
		try {
			assertEquals("Success",dao.modifyHotelDetails("UPDATE Hotel SET avg_rate_per_night = 2000 WHERE hotel_id='H24'"));
		} 
		catch (Exception e) {
			System.err.println("Error in Junit Testing !!!");
		}
	}

}
