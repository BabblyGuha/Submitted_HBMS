select * from roomdetails;
select * from bookingdetails;
select * from hotel;
select * from users;
select hotel_id from hotel;

truncate table roomdetails;

drop sequence booking_id_sequence_query;
create sequence room_id_sequence_query start with 1 increment by 1;
select room_id_sequence_query.NEXTVAL from dual;

create sequence booking_id_sequence_query start with 1 increment by 1;
select booking_id_sequence_query.NEXTVAL from dual;

create sequence Employee_id_Sequence_query start with 1 increment by 1;
select Employee_id_Sequence_query.NEXTVAL from dual;

create sequence Customer_id_Sequence_query start with 1 increment by 1;
select Customer_id_Sequence_query.NEXTVAL from dual;

create sequence Hotel_id_Sequence_query start with 1 increment by 1;
select Hotel_id_Sequence_query.NEXTVAL from dual;

alter table roomdetails add foreign key(hotel_id) references hotel(hotel_id);
alter table bookingdetails add foreign key(room_id) references roomdetails(room_id);
alter table bookingdetails add foreign key(user_id) references users(user_id);
alter table roomdetails add constraint hu unique(room_no);

delete from roomdetails;
delete from bookingDetails where booking_id = 'B05';

SELECT booking_id,room_id,b.user_id,user_name,password,mobile_no,phone,address,email,to_char(booked_from,'dd/MM/YYYY'),to_char(booked_to,'dd/MM/YYYY'),no_of_adults,no_of_children,amount from Users u, BookingDetails b WHERE b.user_id=u.user_id and room_id in (SELECT room_id FROM RoomDetails WHERE hotel_id = 'H41')
SELECT 'E'||TO_CHAR(Employee_id_Sequence_Query.CURRVAL,'FM00'),role FROM Users;

insert into USERS values ('C'||TO_CHAR(Customer_id_Sequence_query.NEXTVAL,'FM00'),'Kg@123','Customer','Krishna Guha','9852284763','562160','Kharagpur','Kg@gmail.com');

update roomdetails set room_id = 'R09' where room_id = 'R9';


CREATE TABLE BookingDetails(
booking_id VARCHAR2(4) PRIMARY KEY,
room_id VARCHAR2(4)  REFERENCES RoomDetails(room_id) ON DELETE SET NULL,
user_id VARCHAR2(4)  REFERENCES Users(user_id) ON DELETE SET NULL,
booked_from DATE,
booked_to DATE,
no_of_adults NUMBER,
no_of_children NUMBER,
amount NUMBER(6,2));





